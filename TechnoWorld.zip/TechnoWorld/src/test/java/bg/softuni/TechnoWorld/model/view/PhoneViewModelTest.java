package bg.softuni.TechnoWorld.model.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PhoneViewModelTest {

    PhoneViewModel phoneViewModel;

    @BeforeEach
    void setUp(){
        phoneViewModel = new PhoneViewModel()
                .setId(1L)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand("IPHONE")
                .setInches(14.4)
                .setUser("Pesho");
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, phoneViewModel.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, phoneViewModel.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, phoneViewModel.getInches());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,phoneViewModel.getId());
    }

    @Test
    void checkUser(){
        String user = "Pesho";
        Assertions.assertEquals(user, phoneViewModel.getUser());
    }
}
