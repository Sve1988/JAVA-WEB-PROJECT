package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    private Role role;

    @Mock
    private UserRepository mockUserRepo;

    @BeforeEach
    void setUp() {
        mockUserRepo.deleteAll();
    }

    @Test
    void calculateBalance(){
        role = new Role();
        role.setName(RoleEnum.USER);
        User user = new User();
        user.setRole(role);
        user.setFirstName("Chocho");
        user.setLastName("Chocho");
        user.setBalance(1000);
        user.setEmail("chocho@abv.bg");
        user.setPassword("1111");

        mockUserRepo.saveAndFlush(user);

        Assertions.assertEquals(user.getBalance(), 1000);
    }
}
