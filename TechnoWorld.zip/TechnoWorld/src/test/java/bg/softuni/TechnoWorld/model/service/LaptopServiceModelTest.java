package bg.softuni.TechnoWorld.model.service;

import bg.softuni.TechnoWorld.model.entity.Laptop;
import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class LaptopServiceModelTest {
    private Role role;

    private User user;

    private LaptopServiceModel laptop;

    @BeforeEach
    void setUp(){
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        laptop = new LaptopServiceModel()
                .setId(1L)
                .setUser(user)
                .setModel("Pavilion")
                .setInches(14.4)
                .setPrice(1000)
                .setBrand(new LaptopBrand().setName(LaptopBrandEnum.HP));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, laptop.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, laptop.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, laptop.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,laptop.getUser());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,laptop.getId());
    }
}
