package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

@ExtendWith(MockitoExtension.class)
public class UserTest {

    private Role role;

    private User user;

    Laptop laptop;

    Phone phone;

    SmartTV smartTV;

    @BeforeEach
    void setUp(){
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        laptop = new Laptop()
                .setUser(user)
                .setModel("Pavilion")
                .setInches(14.4)
                .setPrice(1000)
                .setBrand(new LaptopBrand().setName(LaptopBrandEnum.HP));
        user.setLaptops(List.of(laptop));

        phone = new Phone()
                .setUser(user)
                .setInches(14.4)
                .setPrice(1000)
                .setModel("13")
                .setBrand(new PhoneBrand().setName(PhoneBrandEnum.IPHONE));
        user.setPhones(List.of(phone));

        smartTV = new SmartTV()
                .setUser(user)
                .setInches(14.4)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand(new SmartTVBrand().setName(SmartTVBrandEnum.LG));
        user.setSmartTVs(List.of(smartTV));
    }

    @Test
    void checkLastName(){
        String lastName = "Toshev";
        Assertions.assertEquals(lastName, user.getLastName());
    }

    @Test
    void checkFirstName(){
        String firstName = "Tosho";
        Assertions.assertEquals(firstName, user.getFirstName());
    }

    @Test
    void checkBalance(){
        int balance = 1000;
        Assertions.assertEquals(balance, user.getBalance());
    }

    @Test
    void checkEmail(){
        String password = "1234";
        Assertions.assertEquals(password, user.getPassword());
    }

    @Test
    void checkPassword(){
        String email = "tosho@abv.bg";
        Assertions.assertEquals(email, user.getEmail());
    }

    @Test
    void checkLaptop(){
        Assertions.assertEquals(1,user.getLaptops().size());
    }

    @Test
    void checkPhone(){
        Assertions.assertEquals(1,user.getPhones().size());
    }

    @Test
    void checkTV(){
        Assertions.assertEquals(1,user.getSmartTVs().size());
    }
}
