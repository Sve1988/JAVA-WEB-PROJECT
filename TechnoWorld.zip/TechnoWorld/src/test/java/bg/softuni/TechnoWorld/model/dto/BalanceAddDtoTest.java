package bg.softuni.TechnoWorld.model.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BalanceAddDtoTest {

    BalanceAddDto balanceAddDto;

    @BeforeEach
    void setUp(){
        balanceAddDto = new BalanceAddDto()
                .setCardNumber("8888888888888888")
                .setCardOwner("PETAR PETROV")
                .setAddBalance(1000)
                .setCVV("999");
    }

    @Test
    void checkBalance(){
        int price = 1000;
        Assertions.assertEquals(price, balanceAddDto.getAddBalance());
    }

    @Test
    void checkCardNumber(){
        String number = "8888888888888888";
        Assertions.assertEquals(number, balanceAddDto.getCardNumber());
    }

    @Test
    void checkCardOwner(){
        String owner = "PETAR PETROV";
        Assertions.assertEquals(owner, balanceAddDto.getCardOwner());
    }

    @Test
    void checkCVV(){
        String text = "999";
        Assertions.assertEquals(text, balanceAddDto.getCVV());
    }
}
