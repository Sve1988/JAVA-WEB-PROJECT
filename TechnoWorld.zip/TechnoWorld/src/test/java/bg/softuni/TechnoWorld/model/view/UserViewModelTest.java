package bg.softuni.TechnoWorld.model.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserViewModelTest {

    UserViewModel userViewModel;

    @BeforeEach
    void setUp(){
        userViewModel = new UserViewModel()
                .setId(1L)
                .setEmail("pesho@abv.bg")
                .setBalance(1000)
                .setFirstName("Pesho")
                .setLastName("Peshov");
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, userViewModel.getBalance());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,userViewModel.getId());
    }

    @Test
    void checkEmail(){
        String mail = "pesho@abv.bg";
        Assertions.assertEquals(mail, userViewModel.getEmail());
    }

    @Test
    void checkFirstName(){
        String name = "Pesho";
        Assertions.assertEquals(name, userViewModel.getFirstName());
    }

    @Test
    void checkLastName(){
        String name = "Peshov";
        Assertions.assertEquals(name, userViewModel.getLastName());
    }
}
