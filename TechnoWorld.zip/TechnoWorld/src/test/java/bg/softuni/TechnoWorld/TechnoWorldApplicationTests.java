package bg.softuni.TechnoWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechnoWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
