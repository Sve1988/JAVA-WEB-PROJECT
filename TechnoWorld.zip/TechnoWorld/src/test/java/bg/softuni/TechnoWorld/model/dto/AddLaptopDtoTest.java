package bg.softuni.TechnoWorld.model.dto;

import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AddLaptopDtoTest {

    AddLaptopDto addLaptopDto;

    @BeforeEach
    void setUp(){
        addLaptopDto = new AddLaptopDto()
                .setModel("Pavilion")
                .setInches(14.4)
                .setPrice(1000)
                .setBrand(LaptopBrandEnum.HP);
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, addLaptopDto.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, addLaptopDto.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, addLaptopDto.getInches());
    }
}
