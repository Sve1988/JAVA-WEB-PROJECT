package bg.softuni.TechnoWorld.model.service;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.SmartTV;
import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SmartTVServiceModelTest {

    private Role role;

    private User user;

    private SmartTVServiceModel smartTV;

    @BeforeEach
    void setUp() {
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        smartTV = new SmartTVServiceModel()
                .setId(1L)
                .setUser(user)
                .setInches(14.4)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand(new SmartTVBrand().setName(SmartTVBrandEnum.LG));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, smartTV.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, smartTV.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, smartTV.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,smartTV.getUser());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,smartTV.getId());
    }
}
