package bg.softuni.TechnoWorld.model.dto;

import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AddPhoneDtoTest {

    AddPhoneDto addPhoneDto;

    @BeforeEach
    void setUp(){
        addPhoneDto = new AddPhoneDto()
                .setInches(14.4)
                .setPrice(1000)
                .setModel("13")
                .setBrand(PhoneBrandEnum.IPHONE);
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, addPhoneDto.getPrice());
    }

    @Test
    void checkModel(){
        String model = "13";
        Assertions.assertEquals(model, addPhoneDto.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, addPhoneDto.getInches());
    }
}
