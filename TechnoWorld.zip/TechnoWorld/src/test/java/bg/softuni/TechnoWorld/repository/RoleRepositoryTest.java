package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
public class RoleRepositoryTest {
    Role role;
    User userEntity;

    @Autowired
    RoleRepository roleRepository;
    @Autowired
    UserRepository userEntityRepository;

    @BeforeEach
    void setUp() throws Exception {
        role = new Role();
        role.setName(RoleEnum.USER);
        roleRepository.saveAndFlush(role);
        Role returnedRole = roleRepository.findRoleByName(role.getName()).orElseThrow(Exception::new);

        userEntity = new User();
        userEntity
                .setEmail("some@email.bg")
                .setPassword("asd")
                .setFirstName("Petar")
                .setLastName("Stoyanov")
                .setRole(returnedRole);
        userEntityRepository.saveAndFlush(userEntity);


    }

    @Test
    public void findRoleByName() throws Exception {
        List<User> list = new ArrayList<>();
        list.add(userEntity);
        role.setUsers(list);

        Role roleFound = roleRepository.findRoleByName(RoleEnum.USER).orElseThrow(Exception::new);
        assertEquals(roleFound.getName(), RoleEnum.USER);
    }

    @AfterEach
    void tearDown() {
        roleRepository.deleteAll();
    }
}
