package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SmartTVTest {

    private Role role;

    private User user;

    private SmartTV smartTV;

    @BeforeEach
    void setUp() {
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        smartTV = new SmartTV()
                .setUser(user)
                .setInches(14.4)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand(new SmartTVBrand().setName(SmartTVBrandEnum.LG));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, smartTV.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, smartTV.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, smartTV.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,smartTV.getUser());
    }
}
