package bg.softuni.TechnoWorld.model.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SmartTVsViewModelTest {

    SmartTVsViewModel smartTVsViewModel;

    @BeforeEach
    void setUp(){
        smartTVsViewModel = new SmartTVsViewModel()
                .setId(1L)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand("IPHONE")
                .setInches(14.4)
                .setUser("Pesho");
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, smartTVsViewModel.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, smartTVsViewModel.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, smartTVsViewModel.getInches());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,smartTVsViewModel.getId());
    }

    @Test
    void checkUser(){
        String user = "Pesho";
        Assertions.assertEquals(user, smartTVsViewModel.getUser());
    }
}
