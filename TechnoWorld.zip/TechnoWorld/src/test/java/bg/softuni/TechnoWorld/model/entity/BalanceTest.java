package bg.softuni.TechnoWorld.model.entity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BalanceTest {

    private Balance balance;

    @BeforeEach
    void setUp(){
        balance = new Balance()
                .setCardOwner("PETAR PETROV")
                .setCardNumber("8888888888888888")
                .setCVV("999")
                .setAddBalance(1000);
    }

    @Test
    void checkBalance(){
        int sum = 1000;
        Assertions.assertEquals(sum, balance.getAddBalance());
    }

    @Test
    void checkCardOwner(){
        String owner = "PETAR PETROV";
        Assertions.assertEquals(owner, balance.getCardOwner());
    }

    @Test
    void checkCVV(){
        String text = "999";
        Assertions.assertEquals(text, balance.getCVV());
    }

    @Test
    void checkCardNumber(){
        String text = "8888888888888888";
        Assertions.assertEquals(text, balance.getCardNumber());
    }
}
