package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class UserRepositoryTest {

    @Autowired
    UserRepository userEntityRepository;
    @Autowired
    RoleRepository roleRepository;

    @BeforeEach
    void setUp() throws Exception {
        Role role = new Role();
        role.setName(RoleEnum.USER);
        roleRepository.saveAndFlush(role);
        Role returnedRole = roleRepository.findRoleByName(role.getName()).orElseThrow(Exception::new);

        User userEntity = new User();
        userEntity
                .setEmail("some@email.bg")
                .setPassword("asd")
                .setFirstName("Petar")
                .setLastName("Stoyanov")
                .setRole(returnedRole);
        userEntityRepository.saveAndFlush(userEntity);
    }

    @AfterEach
    void tearDown() {
        userEntityRepository.deleteAll();
        roleRepository.deleteAll();
    }
}
