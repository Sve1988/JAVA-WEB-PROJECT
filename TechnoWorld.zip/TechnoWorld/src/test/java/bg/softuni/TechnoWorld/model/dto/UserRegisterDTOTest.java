package bg.softuni.TechnoWorld.model.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class UserRegisterDTOTest {

    UserRegisterDTO userRegisterDTO;

    @BeforeEach
    void setUp(){
        userRegisterDTO = new UserRegisterDTO()
                .setFirstName("Ivan")
                .setLastName("Ivanov")
                .setEmail("ivan@abv.bg")
                .setPassword("1234")
                .setConfirmPassword("1234");
    }

    @Test
    void checkFirstName(){
        String name = "Ivan";
        Assertions.assertEquals(name, userRegisterDTO.getFirstName());
    }

    @Test
    void checkLastName(){
        String name = "Ivanov";
        Assertions.assertEquals(name, userRegisterDTO.getLastName());
    }

    @Test
    void checkMail(){
        String mail = "ivan@abv.bg";
        Assertions.assertEquals(mail, userRegisterDTO.getEmail());
    }

    @Test
    void checkPass(){
        String pass = "1234";
        Assertions.assertEquals(pass, userRegisterDTO.getPassword());
    }

    @Test
    void checkConfirmPass(){
        String pass = "1234";
        Assertions.assertEquals(pass, userRegisterDTO.getConfirmPassword());
    }
}
