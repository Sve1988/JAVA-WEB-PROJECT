package bg.softuni.TechnoWorld.model.service;

import bg.softuni.TechnoWorld.model.entity.Phone;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PhoneServiceModelTest {

    private Role role;

    private User user;

    private PhoneServiceModel phone;

    @BeforeEach
    void setUp(){
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        phone = new PhoneServiceModel()
                .setId(1L)
                .setUser(user)
                .setInches(14.4)
                .setPrice(1000)
                .setModel("13")
                .setBrand(new PhoneBrand().setName(PhoneBrandEnum.IPHONE));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, phone.getPrice());
    }

    @Test
    void checkModel(){
        String model = "13";
        Assertions.assertEquals(model, phone.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, phone.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,phone.getUser());
    }

    @Test
    void checkId(){
        long id = 1L;
        Assertions.assertEquals(id,phone.getId());
    }
}
