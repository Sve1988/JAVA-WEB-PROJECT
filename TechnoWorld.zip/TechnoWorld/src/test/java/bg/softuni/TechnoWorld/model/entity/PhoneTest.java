package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PhoneTest {

    private Role role;

    private User user;

    private Phone phone;

    @BeforeEach
    void setUp(){
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        phone = new Phone()
                .setUser(user)
                .setInches(14.4)
                .setPrice(1000)
                .setModel("13")
                .setBrand(new PhoneBrand().setName(PhoneBrandEnum.IPHONE));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, phone.getPrice());
    }

    @Test
    void checkModel(){
        String model = "13";
        Assertions.assertEquals(model, phone.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, phone.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,phone.getUser());
    }
}
