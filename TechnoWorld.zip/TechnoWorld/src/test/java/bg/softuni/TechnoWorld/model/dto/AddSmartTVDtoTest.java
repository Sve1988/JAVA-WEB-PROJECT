package bg.softuni.TechnoWorld.model.dto;

import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class AddSmartTVDtoTest {

    AddSmartTVDto addSmartTVDto;

    @BeforeEach
    void setUp(){
        addSmartTVDto = new AddSmartTVDto()
                .setInches(14.4)
                .setModel("Pavilion")
                .setPrice(1000)
                .setBrand(SmartTVBrandEnum.LG);
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, addSmartTVDto.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, addSmartTVDto.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, addSmartTVDto.getInches());
    }
}
