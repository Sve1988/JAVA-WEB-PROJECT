package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class LaptopTest {

    private Role role;

    private User user;

    private Laptop laptop;

    @BeforeEach
    void setUp(){
        role = new Role();
        role.setName(RoleEnum.USER);
        user = new User()
                .setRole(role)
                .setFirstName("Tosho")
                .setLastName("Toshev")
                .setBalance(1000)
                .setEmail("tosho@abv.bg")
                .setPassword("1234");

        laptop = new Laptop()
                .setUser(user)
                .setModel("Pavilion")
                .setInches(14.4)
                .setPrice(1000)
                .setBrand(new LaptopBrand().setName(LaptopBrandEnum.HP));
    }

    @Test
    void checkPrice(){
        int price = 1000;
        Assertions.assertEquals(price, laptop.getPrice());
    }

    @Test
    void checkModel(){
        String model = "Pavilion";
        Assertions.assertEquals(model, laptop.getModel());
    }

    @Test
    void checkInches(){
        double inches = 14.4;
        Assertions.assertEquals(inches, laptop.getInches());
    }

    @Test
    void checkUser(){
        Assertions.assertEquals(user,laptop.getUser());
    }
}
