package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.model.dto.BalanceAddDto;
import bg.softuni.TechnoWorld.repository.BalanceRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class BalanceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BalanceRepository balanceRepository;

    BalanceAddDto balanceAddDto = new BalanceAddDto();

    @BeforeEach
    void setUp(){
        balanceAddDto.setCardNumber("8888888888888888");
        balanceAddDto.setCardOwner("Pesho Peshev");
        balanceAddDto.setCVV("888");
        balanceAddDto.setAddBalance(5000);
    }

    @AfterEach
    void tearDown(){
        balanceRepository.deleteAll();
    }


    @WithMockUser(roles = "USER")
    @Test
    public void balanceAddPage() throws Exception {
        mockMvc.perform(get("/balance/add"))
                .andExpect(status().is(200));
    }


}
