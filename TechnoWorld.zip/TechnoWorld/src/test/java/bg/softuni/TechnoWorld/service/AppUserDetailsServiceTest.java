package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AppUserDetailsServiceTest {

    private Role role;

    @Mock
    private UserRepository mockUserRepo;

    private AppUserDetailsService toTest;



    @BeforeEach
    void setUp() {
        toTest = new AppUserDetailsService(
                mockUserRepo
        );
    }

    @Test
    void testLoadUserByUsername_UserDoesNotExist() {

        // arrange
        // NOTE: No need to arrange anything, mocks return empty optionals.

        // act && assert
        Assertions.assertThrows(
                UsernameNotFoundException.class,
                () -> toTest.loadUserByUsername("non-existant@example.com")
        );
    }

    @Test
    void testLoadUserByUsername_UserExists() throws Exception {
        role = new Role();
        role.setName(RoleEnum.USER);
        User user = new User()
                .setFirstName("Pesho")
                .setLastName("Peshev")
                .setEmail("pesho@abv.bg")
                .setPassword("1234")
                .setBalance(1000)
                .setRole(role);

        when(mockUserRepo.findByEmail(user.getEmail())).
                thenReturn(Optional.of(user));

        UserDetails userDetails = (UserDetails)
                toTest.loadUserByUsername(user.getEmail());

        Assertions.assertEquals(user.getEmail(), userDetails.getUsername());
        Assertions.assertEquals(user.getPassword(), userDetails.getPassword());
    }



}
