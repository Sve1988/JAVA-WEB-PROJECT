package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LaptopBrandRepository extends JpaRepository<LaptopBrand, Long> {
    Optional<LaptopBrand> findByName(LaptopBrandEnum brand);
}
