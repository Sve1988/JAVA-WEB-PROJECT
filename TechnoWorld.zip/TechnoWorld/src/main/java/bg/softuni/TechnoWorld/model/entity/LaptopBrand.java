package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;

import javax.persistence.*;

@Entity
@Table(name = "laptopBrand")
public class LaptopBrand extends BaseEntity{

    @Column
    @Enumerated(EnumType.STRING)
    private LaptopBrandEnum name;

    public LaptopBrand() {
    }

    public LaptopBrandEnum getName() {
        return name;
    }

    public LaptopBrand setName(LaptopBrandEnum name) {
        this.name = name;
        return this;
    }
}
