package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.dto.UserRegisterDTO;
import bg.softuni.TechnoWorld.model.entity.*;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.model.view.UserViewModel;
import bg.softuni.TechnoWorld.repository.LaptopRepository;
import bg.softuni.TechnoWorld.repository.PhoneRepository;
import bg.softuni.TechnoWorld.repository.SmartTVRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final LaptopRepository laptopRepository;
    private final PhoneRepository phoneRepository;
    private final SmartTVRepository smartTVRepository;
    private final RoleService roleService;
    private final PasswordEncoder passwordEncoder;
    private final ModelMapper modelMapper;

    private final UserDetailsService userDetailsService;

    public UserService(UserRepository userRepository, LaptopRepository laptopRepository, PhoneRepository phoneRepository, SmartTVRepository smartTVRepository, RoleService roleService, PasswordEncoder passwordEncoder, ModelMapper modelMapper, UserDetailsService userDetailsService) {
        this.userRepository = userRepository;
        this.laptopRepository = laptopRepository;
        this.phoneRepository = phoneRepository;
        this.smartTVRepository = smartTVRepository;

        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
        this.modelMapper = modelMapper;

        this.userDetailsService = userDetailsService;
    }

    public void initFirstUser() throws Exception {
        if (this.userRepository.count() == 0) {
            AppUserDetailsService userDetailServiceImpl = new AppUserDetailsService(this.userRepository);

            User userEntity = new User();
            Role role = this.roleService.findRoleByName(RoleEnum.ADMIN);
            userEntity
                    .setFirstName("Svetozar")
                    .setLastName("Tsekov")
                    .setEmail("svetozar@technika.bg")
                    .setPassword(this.passwordEncoder.encode("qwerty"))
                    .setRole(role)
                    .setBalance(0);
            this.userRepository.save(userEntity);
            userDetailServiceImpl.mapAdmin(userEntity);

            User userEntity2 = new User();
            Role role2 = this.roleService.findRoleByName(RoleEnum.USER);
            userEntity2
                    .setFirstName("Ivan")
                    .setLastName("Ivanov")
                    .setEmail("ivan@technika.bg")
                    .setPassword(this.passwordEncoder.encode("12345"))
                    .setRole(role2)
                    .setBalance(0);
            this.userRepository.save(userEntity2);
        }
    }



    public Integer calculateBalance(UserDetails userDetails) {
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        if (user.getBalance() == null) {
            user.setBalance(0);
        }
        return user.getBalance();
    }

    public boolean registerAndLogin(UserRegisterDTO userRegisterDTO) throws Exception {

        if (!userRegisterDTO.getPassword().equals(userRegisterDTO.getConfirmPassword())) {
            return false;
        }
        Optional<User> byEmail = userRepository.findByEmail(userRegisterDTO.getEmail());
        if (byEmail.isPresent()) {
            return false;
        }

        User userEntity = new User()
                .setEmail(userRegisterDTO.getEmail())
                .setFirstName(userRegisterDTO.getFirstName())
                .setLastName(userRegisterDTO.getLastName())
                .setPassword(passwordEncoder.encode(userRegisterDTO.getPassword()))
                .setRole(roleService.findRoleByName(RoleEnum.USER))
                        .setBalance(0);
        userRepository.save(userEntity);
        UserDetails userDetails = userDetailsService.loadUserByUsername(userEntity.getEmail());

        Authentication auth = new UsernamePasswordAuthenticationToken(
                userDetails,
                userDetails.getPassword(),
                userDetails.getAuthorities()
        );

        SecurityContextHolder
                .getContext()
                .setAuthentication(auth);

        return true;
    }

    public List<UserViewModel> getAllProfiles() {

        return userRepository.findAll()
                .stream()
                .map(user -> {
                    UserViewModel userViewModel = modelMapper.map(user, UserViewModel.class);
                    userViewModel.setEmail(user.getEmail());
                    userViewModel.setBalance(user.getBalance() == null ? 0 : user.getBalance());
                    userViewModel.setFirstName(user.getFirstName());
                    userViewModel.setLastName(user.getLastName());
                    return userViewModel;
                })
                .collect(Collectors.toList());
    }

    public void deleteProfile(Long id) throws Exception{
        User user = userRepository.findById(id).orElse(null);
        List<Laptop> laptops = laptopRepository.findAllByUserId(id);
        for (Laptop laptop: laptops) {
            laptopRepository.delete(laptop);
        }

        List<Phone> phones = phoneRepository.findAllByUserId(id);
        for (Phone phone : phones) {
            phoneRepository.delete(phone);
        }

        List<SmartTV> smartTVS = smartTVRepository.findAllByUserId(id);
        for (SmartTV smartTV: smartTVS) {
            smartTVRepository.delete(smartTV);
        }

        userRepository.deleteById(id);
    }
}
