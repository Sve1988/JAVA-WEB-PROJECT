package bg.softuni.TechnoWorld.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "laptops")
public class Laptop extends BaseEntity{

    @Column(nullable = false)
    private String model;
    @Column(nullable = false)
    private Integer price;
    @Column(nullable = false)
    private Double inches;

    @ManyToOne
    private LaptopBrand brand;
    @ManyToOne
    private User user;

    public Laptop() {
    }

    public String getModel() {
        return model;
    }

    public Laptop setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public Laptop setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public LaptopBrand getBrand() {
        return brand;
    }

    public Laptop setBrand(LaptopBrand brand) {
        this.brand = brand;
        return this;
    }

    public User getUser() {
        return user;
    }

    public Laptop setUser(User user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public Laptop setInches(Double inches) {
        this.inches = inches;
        return this;
    }



}
