package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {

    @GetMapping("/")
    public String checkBalance(Model model){
        return "index";
    }

    @GetMapping("/oops")
    public String oops(Model model){
        return "oops";
    }

}
