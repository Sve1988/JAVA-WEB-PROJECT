package bg.softuni.TechnoWorld.model.dto;

import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class AddLaptopDto {

    @NotBlank
    private String model;
    @NotNull
    @Positive
    private Integer price;
    @NotNull
    private Double inches;
    @NotNull
    private LaptopBrandEnum brand;

    public AddLaptopDto() {
    }

    public String getModel() {
        return model;
    }

    public AddLaptopDto setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public AddLaptopDto setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public LaptopBrandEnum getBrand() {
        return brand;
    }

    public AddLaptopDto setBrand(LaptopBrandEnum brand) {
        this.brand = brand;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public AddLaptopDto setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
