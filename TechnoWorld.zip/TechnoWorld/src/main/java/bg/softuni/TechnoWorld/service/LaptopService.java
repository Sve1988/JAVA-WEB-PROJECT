package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Laptop;
import bg.softuni.TechnoWorld.model.entity.Phone;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.service.LaptopServiceModel;
import bg.softuni.TechnoWorld.model.view.LaptopViewModel;
import bg.softuni.TechnoWorld.model.view.PhoneViewModel;
import bg.softuni.TechnoWorld.repository.LaptopRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LaptopService {

    private final LaptopRepository laptopRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;

    public LaptopService(LaptopRepository laptopRepository, ModelMapper modelMapper, UserRepository userRepository) {
        this.laptopRepository = laptopRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
    }

    public void addLaptop(LaptopServiceModel laptopServiceModel, UserDetails userDetails) {
        Laptop laptop = modelMapper.map(laptopServiceModel, Laptop.class);
        laptopRepository.save(laptop);
    }

    public List<LaptopViewModel> findAllLaptopsView() {
        return laptopRepository.findAll()
                .stream()
                .map(laptop -> {
                    LaptopViewModel viewModel = modelMapper.map(laptop, LaptopViewModel.class);
                    viewModel.setUser(laptop.getUser().getEmail());
                    viewModel.setBrand(laptop.getBrand().getName().name());
                    return viewModel;
                })
                .collect(Collectors.toList());
    }

    public void deleteLaptop(Long id) {
        laptopRepository.deleteById(id);
    }

    public boolean buyLaptop(Long id, UserDetails userDetails) {
        Laptop laptop = laptopRepository.findById(id).orElse(null);
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        if (user.getBalance() >= laptop.getPrice()) {
            laptop.setUser(user);
            laptopRepository.save(laptop);
            user.setBalance(user.getBalance() - laptop.getPrice());
            userRepository.save(user);
            return true;
        } else {
            return false;
        }
    }

    public List<LaptopViewModel> findAll() {

        return this.laptopRepository
                .findAll()
                .stream()
                .map(l -> this.modelMapper.map(l, LaptopViewModel.class))
                .collect(Collectors.toList());

    }
}
