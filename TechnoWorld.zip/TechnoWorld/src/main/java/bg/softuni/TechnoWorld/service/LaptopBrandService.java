package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.enums.LaptopBrandEnum;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.repository.LaptopBrandRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class LaptopBrandService {

    public final LaptopBrandRepository laptopBrandRepository;

    public LaptopBrandService(LaptopBrandRepository laptopBrandRepository) {
        this.laptopBrandRepository = laptopBrandRepository;
    }


    public LaptopBrand findByCategoryEnumName(LaptopBrandEnum brand) {
        return laptopBrandRepository.findByName(brand).orElse(null);
    }

    public void initLaptopBrands() {
        if (laptopBrandRepository.count() == 0) {
            Arrays.stream(LaptopBrandEnum.values())
                    .forEach(laptopBrandEnum -> {
                        LaptopBrand category = new LaptopBrand();
                        category.setName(laptopBrandEnum);
                        laptopBrandRepository.save(category);
                    });
        }
    }
}
