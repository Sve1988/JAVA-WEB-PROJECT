package bg.softuni.TechnoWorld.model.dto;


import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class AddSmartTVDto {

    @NotBlank
    private String model;
    @NotNull
    @Positive
    private Integer price;
    @NotNull
    @Column(nullable = false)
    private Double inches;
    @NotNull
    private SmartTVBrandEnum brand;

    public AddSmartTVDto() {
    }

    public String getModel() {
        return model;
    }

    public AddSmartTVDto setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public AddSmartTVDto setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public SmartTVBrandEnum getBrand() {
        return brand;
    }

    public AddSmartTVDto setBrand(SmartTVBrandEnum brand) {
        this.brand = brand;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public AddSmartTVDto setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
