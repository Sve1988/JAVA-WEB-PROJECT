package bg.softuni.TechnoWorld.model.enums;

public enum PhoneBrandEnum {
    IPHONE, SAMSUNG, NOKIA, MOTOROLA
}
