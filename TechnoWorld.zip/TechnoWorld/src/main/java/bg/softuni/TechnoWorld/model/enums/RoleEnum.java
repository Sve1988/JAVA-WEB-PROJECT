package bg.softuni.TechnoWorld.model.enums;

public enum RoleEnum {
    ADMIN,USER
}
