package bg.softuni.TechnoWorld.model.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "balance")
public class Balance extends BaseEntity{

    private String cardNumber;
    private String cardOwner;
    private String CVV;
    private Integer addBalance;

    public Balance() {
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public Balance setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public String getCardOwner() {
        return cardOwner;
    }

    public Balance setCardOwner(String cardOwner) {
        this.cardOwner = cardOwner;
        return this;
    }

    public String getCVV() {
        return CVV;
    }

    public Balance setCVV(String CVV) {
        this.CVV = CVV;
        return this;
    }

    public Integer getAddBalance() {
        return addBalance;
    }

    public Balance setAddBalance(Integer addBalance) {
        this.addBalance = addBalance;
        return this;
    }
}
