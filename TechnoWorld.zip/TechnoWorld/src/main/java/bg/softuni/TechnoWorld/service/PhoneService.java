package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Phone;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.service.PhoneServiceModel;
import bg.softuni.TechnoWorld.model.view.PhoneViewModel;
import bg.softuni.TechnoWorld.repository.PhoneRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PhoneService {

    private final PhoneRepository phoneRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;


    public PhoneService(PhoneRepository phoneRepository, ModelMapper modelMapper, UserRepository userRepository) {
        this.phoneRepository = phoneRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;

    }

    public PhoneBrand findByCategoryEnumName(PhoneBrandEnum brand) {
       return phoneRepository.findByBrand(brand).orElse(null);
    }


    public void addPhone(PhoneServiceModel phoneServiceModel, UserDetails userDetails) {
        Phone phone = modelMapper.map(phoneServiceModel, Phone.class);
        phoneRepository.save(phone);
    }

    public List<PhoneViewModel> findAllPhonesView() {
        return phoneRepository.findAll()
                .stream()
                .map(album -> {
                    PhoneViewModel viewModel = modelMapper.map(album, PhoneViewModel.class);
                    viewModel.setUser(album.getUser().getEmail());
                    viewModel.setBrand(album.getBrand().getName().name());
                    return viewModel;
                })
                .collect(Collectors.toList());
    }

    public void deletePhone(Long id) {
        phoneRepository.deleteById(id);
    };

    public boolean buyPhone(Long id, UserDetails userDetails) {
        Phone phone = phoneRepository.findById(id).orElse(null);
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        if (user.getBalance() >= phone.getPrice()) {
            phone.setUser(user);
            phoneRepository.save(phone);
            user.setBalance(user.getBalance() - phone.getPrice());
            userRepository.save(user);
            return true;

        } else {
            return false;
        }
    }
}
