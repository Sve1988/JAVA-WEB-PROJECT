package bg.softuni.TechnoWorld.model.dto;

import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class AddPhoneDto {

    @NotBlank
    private String model;
    @NotNull
    @Positive
    private Integer price;
    @NotNull
    private PhoneBrandEnum brand;
    @NotNull
    private Double inches;

    public AddPhoneDto() {
    }

    public String getModel() {
        return model;
    }

    public AddPhoneDto setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public AddPhoneDto setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public PhoneBrandEnum getBrand() {
        return brand;
    }

    public AddPhoneDto setBrand(PhoneBrandEnum brand) {
        this.brand = brand;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public AddPhoneDto setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
