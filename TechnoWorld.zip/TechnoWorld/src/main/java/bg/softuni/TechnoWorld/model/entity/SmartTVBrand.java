package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;

import javax.persistence.*;

@Entity
@Table(name = "smarTVBrand")
public class SmartTVBrand extends BaseEntity{

    @Column
    @Enumerated(EnumType.STRING)
    private SmartTVBrandEnum name;

    public SmartTVBrand() {
    }

    public SmartTVBrandEnum getName() {
        return name;
    }

    public SmartTVBrand setName(SmartTVBrandEnum name) {
        this.name = name;
        return this;
    }
}
