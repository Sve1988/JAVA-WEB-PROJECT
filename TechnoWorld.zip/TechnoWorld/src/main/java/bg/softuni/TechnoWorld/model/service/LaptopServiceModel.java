package bg.softuni.TechnoWorld.model.service;

import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.User;

public class LaptopServiceModel {

    private Long id;
    private String model;
    private Integer price;
    private LaptopBrand brand;
    private Double inches;
    private User user;

    public LaptopServiceModel() {
    }

    public Long getId() {
        return id;
    }

    public LaptopServiceModel setId(Long id) {
        this.id = id;
        return this;
    }

    public String getModel() {
        return model;
    }

    public LaptopServiceModel setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public LaptopServiceModel setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public LaptopBrand getBrand() {
        return brand;
    }

    public LaptopServiceModel setBrand(LaptopBrand brand) {
        this.brand = brand;
        return this;
    }

    public User getUser() {
        return user;
    }

    public LaptopServiceModel setUser(User user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public LaptopServiceModel setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
