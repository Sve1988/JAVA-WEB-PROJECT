package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.model.dto.AddLaptopDto;
import bg.softuni.TechnoWorld.model.entity.LaptopBrand;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.service.LaptopServiceModel;
import bg.softuni.TechnoWorld.repository.LaptopRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import bg.softuni.TechnoWorld.service.LaptopBrandService;
import bg.softuni.TechnoWorld.service.LaptopService;
import bg.softuni.TechnoWorld.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class LaptopController {

    private final LaptopRepository laptopRepository;
    private final LaptopService laptopService;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final LaptopBrandService laptopBrandService;
    private final UserService userService;

    public LaptopController(LaptopRepository laptopRepository, LaptopService laptopService, ModelMapper modelMapper, UserRepository userRepository, LaptopBrandService laptopBrandService, UserService userService) {
        this.laptopRepository = laptopRepository;
        this.laptopService = laptopService;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.laptopBrandService = laptopBrandService;
        this.userService = userService;
    }

    @GetMapping("/laptops/add")
    public String addLaptop(Model model) {
        return "/laptop-add";
    }

    @PostMapping("/laptops/add")
    public String addOffer(@Valid AddLaptopDto addLaptopDto,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes,
                           @AuthenticationPrincipal UserDetails userDetails) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("addLaptopDto", addLaptopDto);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.addLaptopDto",
                    bindingResult);
            return "redirect:/laptops/add";
        }

        LaptopServiceModel laptopServiceModel = modelMapper.map(addLaptopDto, LaptopServiceModel.class);

        LaptopBrand laptopBrand = laptopBrandService.findByCategoryEnumName(addLaptopDto.getBrand());

        laptopServiceModel.setBrand(laptopBrand);

        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();

        laptopServiceModel.setUser(user);

        laptopService.addLaptop(laptopServiceModel, userDetails);

        return "redirect:/";
    }

    @GetMapping("/laptops/all")
    public String allLaptops(Model model){
        model.addAttribute("laptops", laptopService.findAllLaptopsView());
        return "all-laptops";
    }

    @GetMapping("/delete/laptops/{id}")
    public String deleteLaptop(@PathVariable Long id){
        laptopService.deleteLaptop(id);
        return "redirect:/";
    }

    @GetMapping("/buy/laptops/{id}")
    public String buyLaptop(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails){
        if (laptopService.buyLaptop(id,userDetails)){
            return "redirect:/balance/check";
        }else {
            return "redirect:/oops";
        }

    }

    @ModelAttribute
    public AddLaptopDto addLaptopDto() {
        return new AddLaptopDto();
    }
}
