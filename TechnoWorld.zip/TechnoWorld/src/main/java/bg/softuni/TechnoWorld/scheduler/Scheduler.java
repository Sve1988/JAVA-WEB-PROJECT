package bg.softuni.TechnoWorld.scheduler;

import bg.softuni.TechnoWorld.repository.LaptopRepository;
import bg.softuni.TechnoWorld.repository.PhoneRepository;
import bg.softuni.TechnoWorld.repository.SmartTVRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class Scheduler {
    private final PhoneRepository phoneRepository;
    private final LaptopRepository laptopRepository;
    private final SmartTVRepository smartTVRepository;

    public Scheduler(PhoneRepository phoneRepository, LaptopRepository laptopRepository, SmartTVRepository smartTVRepository) {
        this.phoneRepository = phoneRepository;
        this.laptopRepository = laptopRepository;
        this.smartTVRepository = smartTVRepository;
    }

    @Scheduled(cron = "0 0 23 28 * ?")
    public void priceChange() {
        laptopRepository.findAll()
                .forEach(l -> l.setPrice(l.getPrice() - 100));

        smartTVRepository.findAll()
                .forEach(s -> s.setPrice(s.getPrice() - 50));

        phoneRepository.findAll()
                .forEach(p -> p.setPrice(p.getPrice() - 25));
    }

}
