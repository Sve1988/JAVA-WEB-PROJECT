package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.repository.PhoneBrandRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class PhoneBrandService {

    public final PhoneBrandRepository phoneBrandRepository;

    public PhoneBrandService(PhoneBrandRepository phoneBrandRepository) {
        this.phoneBrandRepository = phoneBrandRepository;
    }

    public PhoneBrand findByCategoryEnumName(PhoneBrandEnum brand) {
        return phoneBrandRepository.findByName(brand).orElse(null);
    }

    public void initPhoneBrands() {
        if (phoneBrandRepository.count() == 0) {
            Arrays.stream(PhoneBrandEnum.values())
                    .forEach(phoneBrandEnum -> {
                        PhoneBrand category = new PhoneBrand();
                        category.setName(phoneBrandEnum);
                        phoneBrandRepository.save(category);
                    });
        }
    }
}
