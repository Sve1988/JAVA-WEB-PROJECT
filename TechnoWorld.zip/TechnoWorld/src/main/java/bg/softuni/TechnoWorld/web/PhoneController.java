package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.model.dto.AddPhoneDto;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.service.PhoneServiceModel;
import bg.softuni.TechnoWorld.repository.UserRepository;
import bg.softuni.TechnoWorld.service.PhoneBrandService;
import bg.softuni.TechnoWorld.service.PhoneService;
import bg.softuni.TechnoWorld.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class PhoneController {

    private final PhoneService phoneService;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final PhoneBrandService phoneBrandService;
    private final UserService userService;

    public PhoneController(PhoneService phoneService, ModelMapper modelMapper, UserRepository userRepository, PhoneBrandService phoneBrandService, UserService userService) {
        this.phoneService = phoneService;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.phoneBrandService = phoneBrandService;
        this.userService = userService;
    }

    @GetMapping("/phones/add")
    public String addPhone(Model model) {
        return "/phone-add";
    }

    @PostMapping("/phones/add")
    public String addOffer(@Valid AddPhoneDto addPhoneDto,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes,
                           @AuthenticationPrincipal UserDetails userDetails) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("addPhoneDto", addPhoneDto);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.addPhoneDto",
                    bindingResult);
            return "redirect:/phones/add";
        }

        PhoneServiceModel phoneServiceModel = modelMapper.map(addPhoneDto, PhoneServiceModel.class);

        PhoneBrand phoneBrand = phoneBrandService.findByCategoryEnumName(addPhoneDto.getBrand());

        phoneServiceModel.setBrand(phoneBrand);

        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();

        phoneServiceModel.setUser(user);

        phoneService.addPhone(phoneServiceModel, userDetails);

        return "redirect:/";
    }

    @GetMapping("/phones/all")
    public String allPhones(Model model){
        model.addAttribute("phones", phoneService.findAllPhonesView());
        return "all-phones";
    }

    @GetMapping("/delete/phones/{id}")
    public String deletePhone(@PathVariable Long id){
        phoneService.deletePhone(id);
        return "redirect:/";
    }

    @GetMapping("/buy/phones/{id}")
    public String buyPhone(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails){
      //  phoneService.buyPhone(id,userDetails)
        if (phoneService.buyPhone(id, userDetails)) {
            return "redirect:/balance/check";
        } else {
            return "redirect:/oops";
        }
    }


    @ModelAttribute
    public AddPhoneDto addPhoneDto() {
        return new AddPhoneDto();
    }
}
