package bg.softuni.TechnoWorld.init;

import bg.softuni.TechnoWorld.service.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class AppInit implements CommandLineRunner {

    private final UserService userService;
    private final RoleService roleService;
    private final PhoneBrandService phoneBrandService;
    private final LaptopBrandService laptopBrandService;
    private final SmartTVBrandService smartTVBrandService;

    public AppInit(UserService userService, RoleService roleService, PhoneBrandService phoneBrandService, LaptopBrandService laptopBrandService, SmartTVBrandService smartTVBrandService) {
        this.userService = userService;
        this.roleService = roleService;
        this.phoneBrandService = phoneBrandService;
        this.laptopBrandService = laptopBrandService;
        this.smartTVBrandService = smartTVBrandService;
    }

    @Override
    public void run(String... args) throws Exception {
        this.roleService.initRoles();
        this.userService.initFirstUser();
        this.phoneBrandService.initPhoneBrands();
        this.laptopBrandService.initLaptopBrands();
        this.smartTVBrandService.initSmartTVBrands();
    }
}
