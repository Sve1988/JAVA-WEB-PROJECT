package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.model.dto.AddSmartTVDto;
import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.service.SmartTVServiceModel;
import bg.softuni.TechnoWorld.repository.UserRepository;
import bg.softuni.TechnoWorld.service.SmartTVBrandService;
import bg.softuni.TechnoWorld.service.SmartTVService;
import bg.softuni.TechnoWorld.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class SmartTVController {

    private final SmartTVService smartTVService;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final SmartTVBrandService smartTVBrandService;
    private final UserService userService;

    public SmartTVController(SmartTVService smartTVService, ModelMapper modelMapper, UserRepository userRepository, SmartTVBrandService smartTVBrandService, UserService userService) {
        this.smartTVService = smartTVService;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.smartTVBrandService = smartTVBrandService;
        this.userService = userService;
    }

    @GetMapping("/smartTVs/add")
    public String addSmartTV(Model model) {
        return "/smartTV-add";
    }

    @PostMapping("/smartTVs/add")
    public String addOffer(@Valid AddSmartTVDto addSmartTVDto,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes,
                           @AuthenticationPrincipal UserDetails userDetails) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("addSmartTVDto", addSmartTVDto);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.addSmartTVDto",
                    bindingResult);
            return "redirect:/smartTVs/add";
        }

        SmartTVServiceModel smartTVServiceModel = modelMapper.map(addSmartTVDto, SmartTVServiceModel.class);

        SmartTVBrand smartTVBrand = smartTVBrandService.findByCategoryEnumName(addSmartTVDto.getBrand());

        smartTVServiceModel.setBrand(smartTVBrand);

        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();

        smartTVServiceModel.setUser(user);

        smartTVService.addSmartTV(smartTVServiceModel, userDetails);

        return "redirect:/";
    }

    @GetMapping("/smartTVs/all")
    public String allSmartTV(Model model){
        model.addAttribute("smartTVs", smartTVService.findAllSmartTVsView());
        return "all-smartTVs";
    }

    @GetMapping("/delete/smartTVs/{id}")
    public String deleteSmartTV(@PathVariable Long id){
        smartTVService.deleteSmartTV(id);
        return "redirect:/";
    }

    @GetMapping("/buy/smartTVs/{id}")
    public String buySmartTV(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails){
       if (smartTVService.buySmartTV(id,userDetails)){
           return "redirect:/balance/check";
       }else {
           return "redirect:/oops";
       }

    }

    @ModelAttribute
    public AddSmartTVDto addSmartTVDto() {
        return new AddSmartTVDto();
    }
}
