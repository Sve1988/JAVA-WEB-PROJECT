package bg.softuni.TechnoWorld.model.view;

public class PhoneViewModel {

    private Long id;
    private String model;
    private Integer price;
    private String brand;
    private Double inches;
    private String user;

    public PhoneViewModel() {
    }

    public Long getId() {
        return id;
    }

    public PhoneViewModel setId(Long id) {
        this.id = id;
        return this;
    }

    public String getModel() {
        return model;
    }

    public PhoneViewModel setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public PhoneViewModel setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public String getBrand() {
        return brand;
    }

    public PhoneViewModel setBrand(String brand) {
        this.brand = brand;
        return this;
    }

    public String getUser() {
        return user;
    }

    public PhoneViewModel setUser(String user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public PhoneViewModel setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
