package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Phone;
import bg.softuni.TechnoWorld.model.entity.SmartTV;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.model.service.SmartTVServiceModel;
import bg.softuni.TechnoWorld.model.view.PhoneViewModel;
import bg.softuni.TechnoWorld.model.view.SmartTVsViewModel;
import bg.softuni.TechnoWorld.repository.SmartTVRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SmartTVService {

    private final SmartTVRepository smartTVRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;

    public SmartTVService(SmartTVRepository smartTVRepository, ModelMapper modelMapper, UserRepository userRepository) {
        this.smartTVRepository = smartTVRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
    }

    public void addSmartTV(SmartTVServiceModel smartTVServiceModel, UserDetails userDetails) {
        SmartTV smartTV = modelMapper.map(smartTVServiceModel, SmartTV.class);
        smartTVRepository.save(smartTV);
    }

    public List<SmartTVsViewModel> findAllSmartTVsView() {
        return smartTVRepository.findAll()
                .stream()
                .map(smartTV -> {
                    SmartTVsViewModel viewModel = modelMapper.map(smartTV, SmartTVsViewModel.class);
                    viewModel.setUser(smartTV.getUser().getEmail());
                    viewModel.setBrand(smartTV.getBrand().getName().name());
                    return viewModel;
                })
                .collect(Collectors.toList());
    }

    public void deleteSmartTV(Long id) {
        smartTVRepository.deleteById(id);
    }

    public boolean buySmartTV(Long id, UserDetails userDetails) {
        SmartTV smartTV = smartTVRepository.findById(id).orElse(null);
        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();
        if (user.getBalance() >= smartTV.getPrice()) {
            smartTV.setUser(user);
            smartTVRepository.save(smartTV);
            user.setBalance(user.getBalance() - smartTV.getPrice());
            userRepository.save(user);
            return true;
        } else {
            return false;
        }
    }
}
