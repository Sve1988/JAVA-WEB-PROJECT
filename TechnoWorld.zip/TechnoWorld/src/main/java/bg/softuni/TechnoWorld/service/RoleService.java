package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.Role;
import bg.softuni.TechnoWorld.model.enums.RoleEnum;
import bg.softuni.TechnoWorld.repository.RoleRepository;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public void initRoles(){
        if (this.roleRepository.count() == 0) {
            Role roleUser = new Role();
            roleUser.setName(RoleEnum.USER);

            Role roleAdmin = new Role();
            roleAdmin.setName(RoleEnum.ADMIN);

            this.roleRepository.save(roleUser);
            this.roleRepository.save(roleAdmin);
        }
    }

    public Role findRoleByName(RoleEnum name) throws Exception {
        return this.roleRepository.findRoleByName(name).orElseThrow(Exception::new);
    }

}
