package bg.softuni.TechnoWorld.model.view;

public class LaptopViewModel {
    private Long id;
    private String model;
    private Integer price;
    private String brand;
    private Double inches;
    private String user;

    public LaptopViewModel() {
    }

    public Long getId() {
        return id;
    }

    public LaptopViewModel setId(Long id) {
        this.id = id;
        return this;
    }

    public String getModel() {
        return model;
    }

    public LaptopViewModel setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public LaptopViewModel setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public String getBrand() {
        return brand;
    }

    public LaptopViewModel setBrand(String brand) {
        this.brand = brand;
        return this;
    }

    public String getUser() {
        return user;
    }

    public LaptopViewModel setUser(String user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public LaptopViewModel setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
