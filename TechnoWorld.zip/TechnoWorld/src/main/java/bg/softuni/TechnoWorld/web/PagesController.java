package bg.softuni.TechnoWorld.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PagesController {

    @GetMapping("/pages/admins")
    public String admins() {
        return "admins";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }
}
