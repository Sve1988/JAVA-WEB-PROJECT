package bg.softuni.TechnoWorld.model.service;

import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.entity.User;

import javax.persistence.Column;

public class SmartTVServiceModel {
    private Long id;
    private String model;
    private Integer price;
    private SmartTVBrand brand;
    private Double inches;
    private User user;

    public SmartTVServiceModel() {
    }

    public Long getId() {
        return id;
    }

    public SmartTVServiceModel setId(Long id) {
        this.id = id;
        return this;
    }

    public String getModel() {
        return model;
    }

    public SmartTVServiceModel setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public SmartTVServiceModel setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public SmartTVBrand getBrand() {
        return brand;
    }

    public SmartTVServiceModel setBrand(SmartTVBrand brand) {
        this.brand = brand;
        return this;
    }

    public User getUser() {
        return user;
    }

    public SmartTVServiceModel setUser(User user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public SmartTVServiceModel setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
