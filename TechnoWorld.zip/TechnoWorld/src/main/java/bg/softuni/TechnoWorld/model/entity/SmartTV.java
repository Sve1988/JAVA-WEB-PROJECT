package bg.softuni.TechnoWorld.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "smartTVs")
public class SmartTV extends BaseEntity{
    @Column(nullable = false)
    private String model;
    @Column(nullable = false)
    private Integer price;
    @Column(nullable = false)
    private Double inches;
    @ManyToOne
    private SmartTVBrand brand;
    @ManyToOne
    private User user;

    public SmartTV() {
    }

    public String getModel() {
        return model;
    }

    public SmartTV setModel(String model) {
        this.model = model;
        return this;
    }

    public Integer getPrice() {
        return price;
    }

    public SmartTV setPrice(Integer price) {
        this.price = price;
        return this;
    }

    public SmartTVBrand getBrand() {
        return brand;
    }

    public SmartTV setBrand(SmartTVBrand brand) {
        this.brand = brand;
        return this;
    }

    public User getUser() {
        return user;
    }

    public SmartTV setUser(User user) {
        this.user = user;
        return this;
    }

    public Double getInches() {
        return inches;
    }

    public SmartTV setInches(Double inches) {
        this.inches = inches;
        return this;
    }
}
