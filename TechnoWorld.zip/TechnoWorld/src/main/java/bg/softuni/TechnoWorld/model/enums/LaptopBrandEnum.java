package bg.softuni.TechnoWorld.model.enums;

public enum LaptopBrandEnum {
    DELL, HP, ASUS, LENOVO
}
