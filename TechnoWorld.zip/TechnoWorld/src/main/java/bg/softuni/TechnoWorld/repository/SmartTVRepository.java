package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.SmartTV;
import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SmartTVRepository extends JpaRepository<SmartTV,Long> {
    Optional<SmartTVBrand> findByBrand(SmartTVBrandEnum brand);

    List<SmartTV> findAllByUserId(Long id);
}
