package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SmartTVBrandRepository extends JpaRepository<SmartTVBrand, Long> {
    Optional<SmartTVBrand> findByName(SmartTVBrandEnum brand);
}
