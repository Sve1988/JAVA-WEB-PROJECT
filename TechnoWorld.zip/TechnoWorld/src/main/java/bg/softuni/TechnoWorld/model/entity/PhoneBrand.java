package bg.softuni.TechnoWorld.model.entity;

import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;

import javax.persistence.*;

@Entity
@Table(name = "phoneBrand")
public class PhoneBrand extends BaseEntity {
    @Column
    @Enumerated(EnumType.STRING)
    private PhoneBrandEnum name;


    public PhoneBrand() {
    }

    public PhoneBrandEnum getName() {
        return name;
    }

    public PhoneBrand setName(PhoneBrandEnum name) {
        this.name = name;
        return this;
    }


}
