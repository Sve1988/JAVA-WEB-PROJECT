package bg.softuni.TechnoWorld.web;

import bg.softuni.TechnoWorld.model.dto.BalanceAddDto;
import bg.softuni.TechnoWorld.model.entity.Balance;
import bg.softuni.TechnoWorld.model.entity.User;
import bg.softuni.TechnoWorld.repository.BalanceRepository;
import bg.softuni.TechnoWorld.repository.UserRepository;
import bg.softuni.TechnoWorld.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class BalanceController {

    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final UserService userService;
    private final BalanceRepository balanceRepository;

    public BalanceController(ModelMapper modelMapper, UserRepository userRepository, UserService userService, BalanceRepository balanceRepository) {
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.userService = userService;
        this.balanceRepository = balanceRepository;
    }

    @GetMapping("/balance/add")
    public String addPBalance(Model model) {
        return "/balance-add";
    }

    @PostMapping("/balance/add")
    public String addOffer(@Valid BalanceAddDto balanceAddDto,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes,
                           @AuthenticationPrincipal UserDetails userDetails) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("balanceAddDto", balanceAddDto);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.balanceAddDto",
                    bindingResult);
            return "redirect:/balance/add";
        }

        Balance balance = modelMapper.map(balanceAddDto, Balance.class);
        balanceRepository.save(balance);

        User user = userRepository.findByEmail(userDetails.getUsername()).orElseThrow();

        int newBalance = user.getBalance() + balanceAddDto.getAddBalance();
        user.setBalance(newBalance);
        userRepository.save(user);
        return "redirect:/";
    }

    @GetMapping("/balance/check")
    public String checkPBalance(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        model.addAttribute("balance", userService.calculateBalance(userDetails));
        return "/balance-check";
    }

    @ModelAttribute
    public BalanceAddDto balanceAddDto() {
        return new BalanceAddDto();
    }
}
