package bg.softuni.TechnoWorld.model.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class BalanceAddDto {

    @NotNull
    @Size(min = 10, max = 20 )
    private String cardNumber;
    @NotNull
    @Size(min = 10)
    private String cardOwner;
    @NotNull
    @Size(min = 3, max = 3)
    private String CVV;
    @Positive
    @NotNull
    private Integer addBalance;


    public BalanceAddDto() {
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public BalanceAddDto setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public Integer getAddBalance() {
        return addBalance;
    }

    public BalanceAddDto setAddBalance(Integer addBalance) {
        this.addBalance = addBalance;
        return this;
    }

    public String getCardOwner() {
        return cardOwner;
    }

    public BalanceAddDto setCardOwner(String cardOwner) {
        this.cardOwner = cardOwner;
        return this;
    }

    public String getCVV() {
        return CVV;
    }

    public BalanceAddDto setCVV(String CVV) {
        this.CVV = CVV;
        return this;
    }
}
