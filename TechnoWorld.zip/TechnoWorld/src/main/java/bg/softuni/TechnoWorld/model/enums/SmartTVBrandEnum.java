package bg.softuni.TechnoWorld.model.enums;

public enum SmartTVBrandEnum {
    PANASONIC,SONY,LG,PHILIPS
}
