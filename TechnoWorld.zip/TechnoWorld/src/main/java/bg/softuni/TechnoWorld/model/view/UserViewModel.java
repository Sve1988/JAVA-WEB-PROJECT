package bg.softuni.TechnoWorld.model.view;

public class UserViewModel {

    private Long id;
    private String email;
    private Integer balance;
    private String firstName;
    private String lastName;

    public UserViewModel() {
    }

    public String getEmail() {
        return email;
    }

    public UserViewModel setEmail(String email) {
        this.email = email;
        return this;
    }

    public Integer getBalance() {
        return balance;
    }

    public UserViewModel setBalance(Integer balance) {
        this.balance = balance;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public UserViewModel setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public UserViewModel setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public Long getId() {
        return id;
    }

    public UserViewModel setId(Long id) {
        this.id = id;
        return this;
    }
}
