package bg.softuni.TechnoWorld.service;

import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.entity.SmartTVBrand;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import bg.softuni.TechnoWorld.model.enums.SmartTVBrandEnum;
import bg.softuni.TechnoWorld.repository.SmartTVBrandRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class SmartTVBrandService {

    public final SmartTVBrandRepository smartTVBrandRepository;

    public SmartTVBrandService(SmartTVBrandRepository smartTVBrandRepository) {
        this.smartTVBrandRepository = smartTVBrandRepository;
    }

    public SmartTVBrand findByCategoryEnumName(SmartTVBrandEnum brand) {
        return smartTVBrandRepository.findByName(brand).orElse(null);
    }

    public void initSmartTVBrands() {
        if (smartTVBrandRepository.count() == 0) {
            Arrays.stream(SmartTVBrandEnum.values())
                    .forEach(smartTVBrandEnum -> {
                        SmartTVBrand category = new SmartTVBrand();
                        category.setName(smartTVBrandEnum);
                        smartTVBrandRepository.save(category);
                    });
        }
    }


}
