package bg.softuni.TechnoWorld.model.entity;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "users")
public class User extends BaseEntity{

    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private String lastName;
    @Column(nullable = false, unique = true)
    private String email;
    @Column(nullable = false)
    private String password;
    @ManyToOne()
    private Role role;
    @OneToMany()
    private List<Phone> phones;
    @OneToMany()
    private List<Laptop> laptops;
    @OneToMany()
    private List<SmartTV> smartTVs;
    @Column
    private Integer balance;


    public User() {
    }

    public String getFirstName() {
        return firstName;
    }

    public User setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public User setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public User setEmail(String email) {
        this.email = email;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public User setPassword(String password) {
        this.password = password;
        return this;
    }

    public Role getRole() {
        return role;
    }

    public User setRole(Role role) {
        this.role = role;
        return this;
    }

    public List<Phone> getPhones() {
        return phones;
    }

    public User setPhones(List<Phone> phones) {
        this.phones = phones;
        return this;
    }

    public List<Laptop> getLaptops() {
        return laptops;
    }

    public User setLaptops(List<Laptop> laptops) {
        this.laptops = laptops;
        return this;
    }

    public Integer getBalance() {
        return balance;
    }

    public User setBalance(Integer balance) {
        this.balance = balance;
        return this;
    }

    public List<SmartTV> getSmartTVs() {
        return smartTVs;
    }

    public User setSmartTVs(List<SmartTV> smartTVs) {
        this.smartTVs = smartTVs;
        return this;
    }

}
