package bg.softuni.TechnoWorld.repository;

import bg.softuni.TechnoWorld.model.entity.Phone;
import bg.softuni.TechnoWorld.model.entity.PhoneBrand;
import bg.softuni.TechnoWorld.model.enums.PhoneBrandEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PhoneRepository extends JpaRepository<Phone, Long> {
    Optional<PhoneBrand> findByBrand(PhoneBrandEnum brand);

    List<Phone> findAllByUserId(Long id);
}
