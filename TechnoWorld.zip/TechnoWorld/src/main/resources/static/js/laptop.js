fetch('http://localhost:8080/api/laptops')
    .then(response => response.json())
    .then(data => {
        data.forEach(
            l => {
                const url = `data:image/jpg;base64,`;
                const laptop = document.querySelectorAll('.prefix');
                laptop.forEach(prod => {
                    if (prod.id == l.id) {
                        const imgElem = prod.querySelector('.img-flag');
                        imgElem.src = url + `${l.picture}`;
                    }
                });
            });
    });
